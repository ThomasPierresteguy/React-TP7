import { useState } from 'react';
import { Grommet, Box, TextArea, Text } from 'grommet';

const theme = {
  global: {
    font: {
      family: 'Roboto',
      size: '18px',
      height: '20px',
    },
    colors: {
      brand: '#FF4040',
      background: '#1D1D1D',
      text: '#FFFFFF',
    },
  },
  text: {
    small: {
      size: '14px',
    },
  },
  textInput: {
    extend: `
      background-color: #2E2E2E;
      border-radius: 4px;
      padding: 12px;
      font-family: 'Roboto', sans-serif;
      font-size: 18px;
      color: #FFFFFF;
      border: none;
      &:focus {
        outline: none;
        box-shadow: 0 0 0 2px #FF4040;
      }
    `,
  },
};

function App() {
  const [texto, setTexto] = useState('');

  function cambioTexto(e) {
    setTexto(e.target.value);
  }

  const palabraCount = texto.trim().split(/\s+/).length;

  return (
    <Grommet theme={theme}>
      <Box pad="medium">
        <TextArea value={texto} onChange={cambioTexto} placeholder="Ingrese su texto aquí" size="large" />
        <Text color={texto.length > 100 ? "status-critical" : "neutral-1"}>{texto.length}/100 caracteres</Text>
        <Text>{palabraCount} palabras</Text>
      </Box>
    </Grommet>
  );
}

export default App;
